import { useEffect, useState } from 'react';
import { Phone, Mail, MapPin, Award, Users, Heart } from 'lucide-react';

export default function About() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-black/80 backdrop-blur-md border-b border-accent/20 z-50">
        <div className="container flex items-center justify-between h-16">
          <a href="/" className="text-2xl font-bold text-accent hover:text-yellow-400 transition-colors">Azur Concierge</a>
          <div className="hidden md:flex items-center gap-8">
            <a href="/#services" className="text-sm hover:text-accent transition-colors">Services</a>
            <a href="/about" className="text-sm text-accent font-semibold">À Propos</a>
            <a href="/#faq" className="text-sm hover:text-accent transition-colors">FAQ</a>
            <a href="/#contact" className="text-sm hover:text-accent transition-colors">Contact</a>
          </div>
          <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="bg-accent text-black px-6 py-2 rounded-full font-semibold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105">
            Demande Privée
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-96 flex items-center justify-center overflow-hidden pt-16">
        <div className="absolute inset-0 z-0 bg-gradient-to-br from-accent/10 to-black"></div>
        <div className="relative z-10 text-center max-w-3xl mx-auto px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">À Propos d'Azur Concierge</h1>
          <p className="text-xl text-gray-300">Votre partenaire de confiance pour la gestion premium de votre patrimoine</p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 bg-black border-t border-accent/20">
        <div className="container max-w-3xl">
          {/* Intro Section */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold mb-8 text-accent">Notre Histoire</h2>
            <div className="space-y-6 text-lg text-gray-300 leading-relaxed">
              <p>
                Basée à Nice, au cœur de la Côte d'Azur, <span className="text-accent font-semibold">Azur Concierge est née de notre passion pour le voyage, le service et le contact humain.</span> Forts de 20 années d'expérience dans le tourisme, nous avons créé cette conciergerie pour offrir à vos clients une expérience unique et mémorable.
              </p>
              <p>
                Chaque propriété que nous gérons est pour nous un patrimoine à chérir, et nous nous engageons à la valoriser avec élégance, discrétion et professionnalisme, afin que chaque séjour reflète l'exceptionnel.
              </p>
            </div>
          </div>

          {/* Philosophy Section */}
          <div className="mb-20 p-8 rounded-lg border border-accent/20 bg-accent/5">
            <h2 className="text-4xl font-bold mb-8 text-accent">Notre Philosophie</h2>
            <div className="space-y-6 text-lg text-gray-300 leading-relaxed">
              <p>
                Chez Azur Concierge, nous croyons que <span className="text-accent font-semibold">le luxe se cache dans chaque détail.</span> Chaque interaction avec vos clients est une occasion de créer un moment inoubliable, où confort, raffinement et personnalisation se rencontrent.
              </p>
              <p>
                Notre mission est de transformer votre propriété en un lieu d'exception et chaque séjour en une expérience hors du commun, où vos clients se sentent accueillis, choyés et inspirés. <span className="text-accent font-semibold">Avec nous, la gestion devient art, et l'accueil, un véritable voyage.</span>
              </p>
            </div>
          </div>

          {/* Values Section */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold mb-12 text-accent">Nos Valeurs</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="p-6 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
                <Award className="w-12 h-12 text-accent mb-4 group-hover:scale-125 transition-transform" />
                <h3 className="text-xl font-bold mb-3">Excellence</h3>
                <p className="text-gray-400">Nous visons la perfection dans chaque détail, de la photographie à la gestion des voyageurs.</p>
              </div>

              <div className="p-6 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
                <Heart className="w-12 h-12 text-accent mb-4 group-hover:scale-125 transition-transform" />
                <h3 className="text-xl font-bold mb-3">Discrétion</h3>
                <p className="text-gray-400">Votre confiance est notre priorité. Nous respectons votre intimité et celle de vos clients.</p>
              </div>

              <div className="p-6 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
                <Users className="w-12 h-12 text-accent mb-4 group-hover:scale-125 transition-transform" />
                <h3 className="text-xl font-bold mb-3">Engagement</h3>
                <p className="text-gray-400">Nous nous engageons à maximiser vos revenus et à assurer la satisfaction de vos clients.</p>
              </div>
            </div>
          </div>

          {/* Experience Section */}
          <div className="mb-20">
            <h2 className="text-4xl font-bold mb-12 text-accent">Notre Expertise</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-accent font-bold">20+</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Années d'Expérience</h3>
                  <p className="text-gray-400">Deux décennies d'expertise dans le tourisme et la gestion hôtelière.</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-accent font-bold">10+</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Propriétés Gérées</h3>
                  <p className="text-gray-400">Les plus belles propriétés de la Côte d'Azur nous font confiance.</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-accent font-bold">500+</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Voyageurs Satisfaits</h3>
                  <p className="text-gray-400">Plus de 500 clients internationaux ont profité de nos services.</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-accent font-bold">4.8/5</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Note Moyenne</h3>
                  <p className="text-gray-400">Notre engagement envers l'excellence est reconnu par nos clients.</p>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="p-8 rounded-lg border border-accent/20 bg-accent/5 text-center">
            <h2 className="text-3xl font-bold mb-4">Prêt à nous faire confiance ?</h2>
            <p className="text-gray-400 mb-8">Découvrez comment Azur Concierge peut transformer votre propriété en source de revenus premium.</p>
            <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="inline-block bg-accent text-black px-8 py-4 rounded-lg font-bold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105">
              Planifier une consultation
            </a>
          </div>
        </div>
      </section>

      {/* Contact Footer */}
      <section className="py-16 bg-black border-t border-accent/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="group cursor-pointer">
              <Phone className="w-8 h-8 text-accent mx-auto mb-3 group-hover:scale-125 transition-transform" />
              <p className="text-sm text-gray-400 group-hover:text-accent transition-colors">+33 (0)7 82 73 90 45</p>
            </div>
            <div className="group cursor-pointer">
              <Mail className="w-8 h-8 text-accent mx-auto mb-3 group-hover:scale-125 transition-transform" />
              <p className="text-sm text-gray-400 group-hover:text-accent transition-colors">azurconcierge06@hotmail.com</p>
            </div>
            <div className="group cursor-pointer">
              <MapPin className="w-8 h-8 text-accent mx-auto mb-3 group-hover:scale-125 transition-transform" />
              <p className="text-sm text-gray-400 group-hover:text-accent transition-colors">88 rue Corniche Fleurie, 06200 Nice</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
