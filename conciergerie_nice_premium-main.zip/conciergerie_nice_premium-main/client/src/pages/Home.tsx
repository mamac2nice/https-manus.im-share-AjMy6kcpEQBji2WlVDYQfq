import { useState, useEffect } from 'react';
import { ChevronRight, Star, CheckCircle, ArrowRight, Mail, Phone, MapPin, TrendingUp, Users, Clock, DollarSign, Camera, BarChart3, Zap } from 'lucide-react';
import RevenueCalculator from '@/components/RevenueCalculator';

const HERO_IMAGE = "/hero-nice-sunset.jpg";

export default function Home() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-black/80 backdrop-blur-md border-b border-accent/20 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="text-2xl font-bold text-accent">Azur Concierge</div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#services" className="text-sm hover:text-accent transition-colors">Services</a>
            <a href="/about" className="text-sm hover:text-accent transition-colors">À Propos</a>
            <a href="/blog" className="text-sm hover:text-accent transition-colors">Blog</a>
            <a href="#faq" className="text-sm hover:text-accent transition-colors">FAQ</a>
            <a href="#contact" className="text-sm hover:text-accent transition-colors">Contact</a>
          </div>
          <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="bg-accent text-black px-6 py-2 rounded-full font-semibold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105">
            Demande Privée
          </a>
        </div>
      </nav>

      {/* 1️⃣ HERO SECTION */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden pt-16">
        <div className="absolute inset-0 z-0">
          <img src={HERO_IMAGE} alt="Nice Sunset" className="w-full h-full object-cover" style={{ transform: `translateY(${scrollY * 0.5}px)` }} />
          <div className="absolute inset-0 bg-black/40"></div>
        </div>

        <div className="relative z-10 text-center max-w-3xl mx-auto px-4">
          <div className="inline-block mb-6 px-4 py-2 bg-accent/20 border border-accent rounded-full">
            <span className="text-accent text-sm font-semibold">✨ Gestion Airbnb Premium</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Conciergerie Airbnb à Nice
          </h1>

          <p className="text-lg md:text-xl text-gray-300 mb-8 leading-relaxed max-w-2xl">
            Maximisez les revenus de votre appartement sans gérer les voyageurs.
          </p>
          <p className="text-sm text-gray-400 mb-8">
            <a href="/about" className="text-accent hover:text-yellow-400 transition-colors underline">Découvrez notre histoire</a> et pourquoi nous sommes le leader de la gestion Airbnb de luxe sur la Côte d'Azur.
          </p>

          <div className="flex flex-col md:flex-row gap-4 justify-center mb-8">
            <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="bg-accent text-black px-8 py-4 rounded-lg font-bold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Estimer les revenus de mon appartement
            </a>
            <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="border-2 border-accent text-accent px-8 py-4 rounded-lg font-bold hover:bg-accent hover:text-black transition-all duration-300">
              <Phone className="w-5 h-5 inline mr-2" />
              Parler à un expert
            </a>
          </div>

          <div className="flex items-center justify-center gap-2 text-accent">
            <Star className="w-5 h-5 fill-accent" />
            <span className="font-semibold">4,8/5</span>
            <span className="text-gray-400">– +1000 voyageurs accueillis</span>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
          <ChevronRight className="w-6 h-6 text-accent rotate-90" />
        </div>
      </section>

      {/* 2️⃣ CREDIBILITÉ SECTION */}
      <section className="py-20 bg-black border-t border-accent/20">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-16">Des propriétaires nous font confiance à Nice</h2>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center p-6 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
              <p className="text-gray-400 text-sm mb-2">Appartements gérés</p>
              <p className="text-3xl font-bold text-accent">10+</p>
            </div>
            <div className="text-center p-6 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
              <p className="text-gray-400 text-sm mb-2">Voyageurs accueillis</p>
              <p className="text-3xl font-bold text-accent">500+</p>
            </div>
            <div className="text-center p-6 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
              <p className="text-gray-400 text-sm mb-2">Augmentation revenus</p>
              <p className="text-3xl font-bold text-accent">+30%</p>
            </div>
            <div className="text-center p-6 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
              <p className="text-gray-400 text-sm mb-2">Note moyenne</p>
              <p className="text-3xl font-bold text-accent">4,8/5</p>
            </div>
          </div>
        </div>
      </section>

      {/* 3️⃣ REVENUS SECTION */}
      <section className="py-20 bg-black/50 border-t border-accent/20">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-4">Combien peut rapporter votre appartement à Nice ?</h2>
          <p className="text-center text-gray-400 mb-16">Estimations basées sur nos propriétés gérées</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="bg-gradient-to-br from-accent/10 to-accent/5 border border-accent/30 rounded-lg p-8 hover:border-accent transition-all duration-300 group">
              <h3 className="text-2xl font-bold mb-4 group-hover:text-accent transition-colors">Studio</h3>
              <p className="text-gray-400 text-sm mb-2">Revenus mensuels estimés</p>
              <p className="text-3xl font-bold text-accent mb-2">1200€ - 2000€</p>
              <p className="text-xs text-gray-500">par mois</p>
            </div>

            <div className="bg-gradient-to-br from-accent/10 to-accent/5 border border-accent/30 rounded-lg p-8 hover:border-accent transition-all duration-300 group">
              <h3 className="text-2xl font-bold mb-4 group-hover:text-accent transition-colors">T2</h3>
              <p className="text-gray-400 text-sm mb-2">Revenus mensuels estimés</p>
              <p className="text-3xl font-bold text-accent mb-2">2000€ - 3500€</p>
              <p className="text-xs text-gray-500">par mois</p>
            </div>

            <div className="bg-gradient-to-br from-accent/10 to-accent/5 border border-accent/30 rounded-lg p-8 hover:border-accent transition-all duration-300 group">
              <h3 className="text-2xl font-bold mb-4 group-hover:text-accent transition-colors">T3+</h3>
              <p className="text-gray-400 text-sm mb-2">Revenus mensuels estimés</p>
              <p className="text-3xl font-bold text-accent mb-2">3500€ - 6000€+</p>
              <p className="text-xs text-gray-500">par mois</p>
            </div>
          </div>

          <div className="text-center mb-12">
            <a href="/contact" className="bg-accent text-black px-8 py-4 rounded-lg font-bold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105 inline-flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Recevoir mon estimation gratuite
            </a>
          </div>

          <RevenueCalculator />
        </div>
      </section>

      {/* 4️⃣ SERVICES SECTION */}
      <section id="services" className="py-20 bg-black border-t border-accent/20">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-16">Nos Services Premium</h2>

          {/* Service 1: Accueil */}
          <div className="mb-16 p-8 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300">
            <div className="flex items-start gap-6">
              <Users className="w-12 h-12 text-accent flex-shrink-0 mt-2" />
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-4">Accueil et expérience client</h3>
                <p className="text-gray-300 leading-relaxed mb-4">
                  Nous accueillons vos clients avec raffinement et attention à chaque détail, créant une expérience unique et mémorable dès leur arrivée. Chaque séjour devient un moment d'exception, où confort et élégance se conjuguent.
                </p>
              </div>
            </div>
          </div>

          {/* Service 2: Entretien */}
          <div className="mb-16 p-8 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300">
            <div className="flex items-start gap-6">
              <Zap className="w-12 h-12 text-accent flex-shrink-0 mt-2" />
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-4">Entretien et qualité irréprochable</h3>
                <p className="text-gray-300 leading-relaxed mb-4">
                  Après chaque séjour, votre propriété bénéficie d'un ménage professionnel, d'une inspection qualité systématique et d'une maintenance réactive via notre réseau de partenaires locaux triés sur le volet. Linge de luxe et produits d'accueil premium inclus pour garantir un confort et une présentation parfaits à chaque visite.
                </p>
              </div>
            </div>
          </div>

          {/* Service 3: Gestion complète */}
          <div className="mb-16 p-8 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300">
            <div className="flex items-start gap-6">
              <BarChart3 className="w-12 h-12 text-accent flex-shrink-0 mt-2" />
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-4">Gestion complète et sérénité</h3>
                <p className="text-gray-300 leading-relaxed mb-4">
                  Nous nous chargeons de tous les aspects de la gestion : réservation, coordination des services, communication avec les clients et suivi personnalisé. Vous profitez de votre patrimoine en toute sérénité, tandis que nous veillons à ce que chaque séjour reflète l'excellence de votre propriété.
                </p>
              </div>
            </div>
          </div>

          {/* Service 4: Personnalisation */}
          <div className="mb-16 p-8 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300">
            <div className="flex items-start gap-6">
              <Camera className="w-12 h-12 text-accent flex-shrink-0 mt-2" />
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-4">Personnalisation et exclusivité</h3>
                <p className="text-gray-300 leading-relaxed mb-4">
                  Chaque propriété et chaque client sont uniques. Nous adaptons nos services pour répondre aux besoins spécifiques et offrir des expériences sur-mesure, créant un sentiment d'exclusivité et de luxe pour vos clients.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5️⃣ COMMENT ÇA MARCHE */}
      <section className="py-20 bg-black/50 border-t border-accent/20">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-16">Comment fonctionne notre conciergerie</h2>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="relative">
              <div className="bg-accent text-black w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg mb-4">1</div>
              <h3 className="text-xl font-bold mb-2">Contactez-nous</h3>
              <p className="text-gray-400 text-sm">Prenez rendez-vous pour discuter de votre bien</p>
            </div>

            <div className="relative">
              <div className="bg-accent text-black w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg mb-4">2</div>
              <h3 className="text-xl font-bold mb-2">Nous optimisons</h3>
              <p className="text-gray-400 text-sm">Photographie, description et tarification</p>
            </div>

            <div className="relative">
              <div className="bg-accent text-black w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg mb-4">3</div>
              <h3 className="text-xl font-bold mb-2">Nous gérons</h3>
              <p className="text-gray-400 text-sm">Réservations, ménage, support voyageurs</p>
            </div>

            <div className="relative">
              <div className="bg-accent text-black w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg mb-4">4</div>
              <h3 className="text-xl font-bold mb-2">Vous recevez</h3>
              <p className="text-gray-400 text-sm">Vos revenus directement sur votre compte</p>
            </div>
          </div>
        </div>
      </section>

      {/* 6️⃣ POURQUOI NOUS */}
      <section className="py-20 bg-black border-t border-accent/20">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-16">Pourquoi choisir Azur Concierge</h2>

          <div className="max-w-2xl mx-auto space-y-4">
            <div className="flex items-center gap-4 p-4 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
              <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 group-hover:scale-125 transition-transform" />
              <span className="text-lg">✔ Expertise du marché Niçois</span>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
              <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 group-hover:scale-125 transition-transform" />
              <span className="text-lg">✔ Optimisation dynamique des prix</span>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
              <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 group-hover:scale-125 transition-transform" />
              <span className="text-lg">✔ Ménage professionnel</span>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
              <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 group-hover:scale-125 transition-transform" />
              <span className="text-lg">✔ Support voyageurs 24/7</span>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
              <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 group-hover:scale-125 transition-transform" />
              <span className="text-lg">✔ Maximisation du taux d'occupation</span>
            </div>
          </div>
        </div>
      </section>



      {/* 8️⃣ AVIS CLIENTS */}
      <section className="py-20 bg-black border-t border-accent/20">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-16">Ce que disent nos clients</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, j) => (
                  <Star key={j} className="w-5 h-5 fill-accent text-accent" />
                ))}
              </div>
              <p className="text-gray-300 mb-4 italic">"Service parfait, mon appartement est toujours réservé."</p>
              <p className="font-bold">Julien</p>
              <p className="text-gray-400 text-sm">Propriétaire à Nice</p>
            </div>

            <div className="p-8 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, j) => (
                  <Star key={j} className="w-5 h-5 fill-accent text-accent" />
                ))}
              </div>
              <p className="text-gray-300 mb-4 italic">"Mes revenus ont augmenté de 35% en 6 mois. Excellent !"</p>
              <p className="font-bold">Marie</p>
              <p className="text-gray-400 text-sm">Investisseuse</p>
            </div>

            <div className="p-8 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, j) => (
                  <Star key={j} className="w-5 h-5 fill-accent text-accent" />
                ))}
              </div>
              <p className="text-gray-300 mb-4 italic">"Équipe professionnelle et réactive. Je recommande !"</p>
              <p className="font-bold">Pierre</p>
              <p className="text-gray-400 text-sm">Propriétaire Vieux Nice</p>
            </div>
          </div>
        </div>
      </section>

      {/* 8️⃣ BIS TARIFS */}
      <section id="tarifs" className="py-20 bg-black border-t border-accent/20">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-4">Nos Tarifs Premium</h2>
          <p className="text-center text-gray-400 mb-16 max-w-2xl mx-auto">Trois packages adaptés à vos besoins. Choisissez le service qui correspond à votre stratégie.</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {/* PACKAGE ESSENTIEL */}
            <div className="relative p-8 rounded-lg border border-accent/30 hover:border-accent hover:shadow-2xl hover:shadow-accent/20 transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-accent/50 to-accent rounded-t-lg"></div>
              <h3 className="text-2xl font-bold mb-2 text-accent">Essentiel</h3>
              <p className="text-gray-400 text-sm mb-6">Pour débuter sereinement</p>
              
              <div className="mb-8">
                <span className="text-4xl font-bold">20%</span>
                <span className="text-gray-400 ml-2">de commission</span>
              </div>

              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Optimisation annonce Airbnb</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Check-in / Check-out</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Ménage après chaque séjour</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Support voyageurs 24/7</span>
                </li>
              </ul>

              <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="w-full bg-accent/20 text-accent border border-accent px-6 py-3 rounded-lg font-semibold hover:bg-accent hover:text-black transition-all duration-300 block text-center group-hover:scale-105">
                Demander un devis
              </a>
            </div>

            {/* PACKAGE PREMIUM - HIGHLIGHTED */}
            <div className="relative p-8 rounded-lg border-2 border-accent bg-gradient-to-br from-accent/10 to-black hover:shadow-2xl hover:shadow-accent/30 transition-all duration-300 transform hover:-translate-y-2 group scale-105">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-accent text-black px-4 py-1 rounded-full text-xs font-bold">PLUS POPULAIRE</div>
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-accent via-yellow-400 to-accent rounded-t-lg"></div>
              
              <h3 className="text-2xl font-bold mb-2 text-accent">Premium</h3>
              <p className="text-gray-400 text-sm mb-6">Notre best-seller</p>
              
              <div className="mb-8">
                <span className="text-4xl font-bold">25%</span>
                <span className="text-gray-400 ml-2">de commission</span>
              </div>

              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Tout du package Essentiel</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Tarification dynamique</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Photographie professionnelle</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Tableau de bord temps réel</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Gestion des avis clients</span>
                </li>
              </ul>

              <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="w-full bg-accent text-black px-6 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-all duration-300 block text-center group-hover:scale-105">
                Demander un devis
              </a>
            </div>

            {/* PACKAGE PRESTIGE */}
            <div className="relative p-8 rounded-lg border border-accent/30 hover:border-accent hover:shadow-2xl hover:shadow-accent/20 transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-accent/50 to-accent rounded-t-lg"></div>
              <h3 className="text-2xl font-bold mb-2 text-accent">Prestige</h3>
              <p className="text-gray-400 text-sm mb-6">Gestion complète VIP</p>
              
              <div className="mb-8">
                <span className="text-4xl font-bold">Sur</span>
                <span className="text-gray-400 ml-2">devis</span>
              </div>

              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Tout du package Premium</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Gestion multi-propriétés</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Maintenance & rénovations</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Conseils fiscaux & légaux</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">Account manager dédié</span>
                </li>
              </ul>

              <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="w-full bg-accent/20 text-accent border border-accent px-6 py-3 rounded-lg font-semibold hover:bg-accent hover:text-black transition-all duration-300 block text-center group-hover:scale-105">
                Demander un devis
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* 9️⃣ FAQ */}
      <section id="faq" className="py-20 bg-black/50 border-t border-accent/20">
        <div className="container max-w-2xl">
          <h2 className="text-4xl font-bold text-center mb-16">Questions fréquentes</h2>

          <div className="space-y-6">
            <div className="p-6 rounded-lg border border-accent/20 hover:border-accent transition-all duration-300 group">
              <h3 className="font-bold mb-2 group-hover:text-accent transition-colors">Combien coûte la gestion ?</h3>
              <p className="text-gray-400 text-sm">Nous prenons une commission sur les réservations. Aucun frais caché.</p>
            </div>

            <div className="p-6 rounded-lg border border-accent/20 hover:border-accent transition-all duration-300 group">
              <h3 className="font-bold mb-2 group-hover:text-accent transition-colors">Est-ce légal à Nice ?</h3>
              <p className="text-gray-400 text-sm">Oui, nous vous accompagnons dans la réglementation locale.</p>
            </div>

            <div className="p-6 rounded-lg border border-accent/20 hover:border-accent transition-all duration-300 group">
              <h3 className="font-bold mb-2 group-hover:text-accent transition-colors">Qui gère le ménage ?</h3>
              <p className="text-gray-400 text-sm">Notre équipe de ménage professionnel, incluse dans nos services.</p>
            </div>

            <div className="p-6 rounded-lg border border-accent/20 hover:border-accent transition-all duration-300 group">
              <h3 className="font-bold mb-2 group-hover:text-accent transition-colors">Puis-je voir mes revenus en temps réel ?</h3>
              <p className="text-gray-400 text-sm">Oui, tableau de bord complet et transparent 24/7.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 🔟 CONTACT FINAL */}
      <section id="contact" className="py-20 bg-black border-t border-accent/20">
        <div className="container text-center">
          <h2 className="text-4xl font-bold mb-6">Confiez-nous votre appartement à Nice</h2>
          <p className="text-xl text-gray-400 mb-12">Augmentez vos revenus sans gérer les voyageurs.</p>

          <div className="flex flex-col md:flex-row gap-4 justify-center mb-12">
            <a href="/contact" className="bg-accent text-black px-8 py-4 rounded-lg font-bold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105 inline-flex items-center justify-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Recevoir une estimation gratuite
            </a>
            <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="border-2 border-accent text-accent px-8 py-4 rounded-lg font-bold hover:bg-accent hover:text-black transition-all duration-300 inline-flex items-center justify-center gap-2">
              <Phone className="w-5 h-5" />
              Planifier un appel
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-12 border-t border-accent/20">
            <div className="text-center group cursor-pointer">
              <Phone className="w-8 h-8 text-accent mx-auto mb-3 group-hover:scale-125 transition-transform duration-300" />
              <p className="text-sm text-gray-400 group-hover:text-accent transition-colors">+33 (0)7 82 73 90 45</p>
            </div>
            <div className="text-center group cursor-pointer">
              <Mail className="w-8 h-8 text-accent mx-auto mb-3 group-hover:scale-125 transition-transform duration-300" />
              <p className="text-sm text-gray-400 group-hover:text-accent transition-colors">azurconcierge06@hotmail.com</p>
            </div>
            <div className="text-center group cursor-pointer">
              <MapPin className="w-8 h-8 text-accent mx-auto mb-3 group-hover:scale-125 transition-transform duration-300" />
              <p className="text-sm text-gray-400 group-hover:text-accent transition-colors">88 rue Corniche Fleurie, 06200 Nice</p>
            </div>
          </div>
        </div>
      </section>

      <style>{`
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        .animate-bounce {
          animation: bounce 2s infinite;
        }
      `}</style>
    </div>
  );
}
