import { useState } from 'react';
import { Phone, Mail, MapPin, CheckCircle } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    nom: '',
    email: '',
    telephone: '',
    typeLogement: '',
    surface: '',
    localisation: '',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    console.log('Form submitted:', formData);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ nom: '', email: '', telephone: '', typeLogement: '', surface: '', localisation: '', message: '' });
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-black/80 backdrop-blur-md border-b border-accent/20 z-50">
        <div className="container flex items-center justify-between h-16">
          <a href="/" className="text-2xl font-bold text-accent hover:text-yellow-400 transition-colors">Azur Concierge</a>
          <div className="hidden md:flex items-center gap-8">
            <a href="/#services" className="text-sm hover:text-accent transition-colors">Services</a>
            <a href="/about" className="text-sm hover:text-accent transition-colors">À Propos</a>
            <a href="/blog" className="text-sm hover:text-accent transition-colors">Blog</a>
            <a href="#faq" className="text-sm hover:text-accent transition-colors">FAQ</a>
            <a href="/contact" className="text-sm text-accent font-semibold">Contact</a>
          </div>
          <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="bg-accent text-black px-6 py-2 rounded-full font-semibold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105">
            Demande Privée
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-96 flex items-center justify-center overflow-hidden pt-16">
        <div className="absolute inset-0 z-0 bg-gradient-to-br from-accent/10 to-black"></div>
        <div className="relative z-10 text-center max-w-3xl mx-auto px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Estimation Gratuite</h1>
          <p className="text-xl text-gray-300">Découvrez le potentiel de revenus de votre propriété</p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 bg-black border-t border-accent/20">
        <div className="container max-w-3xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Form Section */}
            <div>
              <h2 className="text-3xl font-bold mb-8">Formulaire de Pré-qualification</h2>
              
              {submitted ? (
                <div className="p-8 rounded-lg border border-accent/20 bg-accent/10 text-center">
                  <CheckCircle className="w-16 h-16 text-accent mx-auto mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Merci !</h3>
                  <p className="text-gray-300 mb-4">
                    Votre demande a été reçue. Nous vous contacterons très bientôt pour discuter de votre estimation personnalisée.
                  </p>
                  <p className="text-gray-400 text-sm">
                    En attendant, vous pouvez aussi <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="text-accent hover:text-yellow-400 underline">réserver une consultation directe</a>.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Nom */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Nom complet *</label>
                    <input
                      type="text"
                      name="nom"
                      value={formData.nom}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-lg bg-black border border-accent/20 text-white focus:border-accent focus:outline-none transition-colors"
                      placeholder="Jean Dupont"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Adresse email *</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-lg bg-black border border-accent/20 text-white focus:border-accent focus:outline-none transition-colors"
                      placeholder="jean@example.com"
                    />
                  </div>

                  {/* Téléphone */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Téléphone</label>
                    <input
                      type="tel"
                      name="telephone"
                      value={formData.telephone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg bg-black border border-accent/20 text-white focus:border-accent focus:outline-none transition-colors"
                      placeholder="+33 6 12 34 56 78"
                    />
                  </div>

                  {/* Type de Logement */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Type de logement *</label>
                    <select
                      name="typeLogement"
                      value={formData.typeLogement}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-lg bg-black border border-accent/20 text-white focus:border-accent focus:outline-none transition-colors"
                    >
                      <option value="">Sélectionnez un type</option>
                      <option value="studio">Studio</option>
                      <option value="t2">T2 (2 pièces)</option>
                      <option value="t3">T3 (3 pièces)</option>
                      <option value="t4">T4+ (4+ pièces)</option>
                      <option value="villa">Villa</option>
                    </select>
                  </div>

                  {/* Surface */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Surface (m²)</label>
                    <input
                      type="number"
                      name="surface"
                      value={formData.surface}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg bg-black border border-accent/20 text-white focus:border-accent focus:outline-none transition-colors"
                      placeholder="45"
                    />
                  </div>

                  {/* Localisation */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Localisation *</label>
                    <select
                      name="localisation"
                      value={formData.localisation}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-lg bg-black border border-accent/20 text-white focus:border-accent focus:outline-none transition-colors"
                    >
                      <option value="">Sélectionnez une localisation</option>
                      <option value="centre">Nice Centre</option>
                      <option value="promenade">Promenade des Anglais</option>
                      <option value="vieux">Vieux Nice</option>
                      <option value="port">Port Lympia</option>
                      <option value="autre">Autre</option>
                    </select>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Message (optionnel)</label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={4}
                      className="w-full px-4 py-3 rounded-lg bg-black border border-accent/20 text-white focus:border-accent focus:outline-none transition-colors resize-none"
                      placeholder="Parlez-nous de votre propriété..."
                    ></textarea>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full bg-accent text-black px-8 py-4 rounded-lg font-bold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105"
                  >
                    Recevoir mon estimation gratuite
                  </button>

                  <p className="text-gray-400 text-xs text-center">
                    * Champs obligatoires. Vos données sont confidentielles et ne seront jamais partagées.
                  </p>
                </form>
              )}
            </div>

            {/* Info Section */}
            <div>
              <h2 className="text-3xl font-bold mb-8">Nous Contacter</h2>
              
              <div className="space-y-8">
                {/* Phone */}
                <div className="p-6 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
                  <div className="flex items-start gap-4">
                    <Phone className="w-8 h-8 text-accent flex-shrink-0 mt-1 group-hover:scale-125 transition-transform" />
                    <div>
                      <h3 className="text-lg font-bold mb-2">Téléphone</h3>
                      <a href="tel:+33782739045" className="text-gray-300 hover:text-accent transition-colors">
                        +33 (0)7 82 73 90 45
                      </a>
                    </div>
                  </div>
                </div>

                {/* Email */}
                <div className="p-6 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
                  <div className="flex items-start gap-4">
                    <Mail className="w-8 h-8 text-accent flex-shrink-0 mt-1 group-hover:scale-125 transition-transform" />
                    <div>
                      <h3 className="text-lg font-bold mb-2">Email</h3>
                      <a href="mailto:azurconcierge06@hotmail.com" className="text-gray-300 hover:text-accent transition-colors">
                        azurconcierge06@hotmail.com
                      </a>
                    </div>
                  </div>
                </div>

                {/* Address */}
                <div className="p-6 rounded-lg border border-accent/20 hover:border-accent hover:bg-accent/5 transition-all duration-300 group">
                  <div className="flex items-start gap-4">
                    <MapPin className="w-8 h-8 text-accent flex-shrink-0 mt-1 group-hover:scale-125 transition-transform" />
                    <div>
                      <h3 className="text-lg font-bold mb-2">Localisation</h3>
                      <p className="text-gray-300">
                        88 rue Corniche Fleurie<br />
                        06200 Nice, France
                      </p>
                    </div>
                  </div>
                </div>

                {/* CTA */}
                <div className="p-6 rounded-lg border border-accent/20 bg-accent/5">
                  <h3 className="text-lg font-bold mb-4">Préférez un appel direct ?</h3>
                  <p className="text-gray-300 mb-4">
                    Réservez une consultation personnalisée avec nos experts pour discuter de votre propriété.
                  </p>
                  <a
                    href="https://calendly.com/jmb2nice/30min"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block bg-accent text-black px-6 py-3 rounded-lg font-bold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105"
                  >
                    Réserver une consultation
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Footer */}
      <section className="py-16 bg-black border-t border-accent/20">
        <div className="container text-center">
          <p className="text-gray-400">
            © 2025 Azur Concierge. Tous droits réservés. | Gestion Airbnb Premium à Nice
          </p>
        </div>
      </section>
    </div>
  );
}
