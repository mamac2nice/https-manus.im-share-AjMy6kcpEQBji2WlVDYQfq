import { useState } from 'react';
import { ArrowRight, Calendar, User, Search } from 'lucide-react';

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  category: string;
  readTime: string;
  image: string;
}

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "Les Tendances du Tourisme de Luxe à Nice en 2025",
    excerpt: "Découvrez comment les voyageurs haut de gamme redéfinissent leurs attentes et comment les propriétaires peuvent en profiter.",
    content: `
      <h2>Les Tendances du Tourisme de Luxe à Nice en 2025</h2>
      
      <p>La Côte d'Azur connaît une transformation majeure dans le secteur du tourisme de luxe. Après plusieurs années de stabilisation post-pandémie, nous observons en 2025 des tendances qui redéfinissent complètement les attentes des voyageurs haut de gamme. Pour les propriétaires d'appartements de prestige, comprendre ces tendances est essentiel pour maximiser leurs revenus et assurer la satisfaction de leur clientèle.</p>

      <h3>1. L'Authenticité Méditerranéenne Comme Valeur Refuge</h3>
      
      <p>Les voyageurs de luxe ne cherchent plus simplement le confort. Ils recherchent l'<strong>expérience authentique</strong>. Les propriétés qui offrent une immersion dans la culture méditerranéenne — terrasses avec vue sur la mer, accès à des restaurants locaux confidentiels, connexions avec des artisans niçois — attirent une clientèle disposée à payer premium.</p>
      
      <p>À Nice, cela signifie que les appartements dans le Vieux Nice, avec leurs caractéristiques architecturales authentiques et leur proximité avec les marchés locaux, voient leurs revenus augmenter de 25 à 35% comparé aux années précédentes. Les propriétaires qui investissent dans la préservation du caractère local de leurs biens constatent une meilleure occupation et des tarifs plus élevés.</p>

      <h3>2. La Durabilité Comme Critère de Sélection</h3>
      
      <p>Le tourisme de luxe évolue. La nouvelle clientèle haut de gamme — souvent des entrepreneurs et des investisseurs conscients — exige des propriétés <strong>éco-responsables</strong>. Panneaux solaires, systèmes de climatisation efficaces, matériaux durables, et gestion responsable de l'eau ne sont plus des options : ce sont des attentes.</p>
      
      <p>Les propriétés certifiées écologiques ou ayant mis en place des pratiques durables rapportent en moyenne 20% de plus. De plus, ces clients restent plus longtemps et génèrent moins de problèmes, améliorant ainsi le taux d'occupation global.</p>

      <h3>3. Les Séjours Longue Durée Gagnent du Terrain</h3>
      
      <p>Fini l'époque où les séjours de luxe se limitaient à une semaine. Avec la flexibilité du télétravail, les voyageurs de luxe optent pour des <strong>séjours de 2 à 4 semaines</strong>, transformant Nice en base de vie temporaire plutôt qu'en simple destination touristique.</p>
      
      <p>Cette tendance crée une opportunité majeure pour les propriétaires : les tarifs mensuels, même avec une réduction, génèrent souvent plus de revenus que les réservations courtes. De plus, ces clients exigent une gestion impeccable — ménage régulier, maintenance proactive, support 24/7 — ce qui justifie le recours à une conciergerie professionnelle.</p>

      <h3>4. La Technologie Discrète Devient Indispensable</h3>
      
      <p>Les clients de luxe apprécient la technologie, mais pas si elle est envahissante. Les propriétés qui offrent <strong>une connectivité de pointe discrètement intégrée</strong> — WiFi ultra-rapide, systèmes domotiques intuitifs, accès digital aux services — se démarquent.</p>
      
      <p>À Nice, les appartements équipés de systèmes de climatisation intelligents, d'éclairage automatisé et de contrôle d'accès digital attirent une clientèle internationale habituée aux standards hôteliers cinq étoiles. L'investissement initial se rentabilise rapidement par une augmentation des tarifs et une meilleure satisfaction client.</p>

      <h3>5. Les Expériences Culinaires Exclusives</h3>
      
      <p>Le tourisme de luxe à Nice s'articule de plus en plus autour de l'<strong>expérience gastronomique</strong>. Les propriétaires qui proposent des services additionnels — chef privé, accès à des restaurants confidentiels, dégustations de vins locaux — créent une valeur ajoutée considérable.</p>
      
      <p>Cette tendance ouvre de nouvelles sources de revenus : les propriétaires peuvent proposer des packages "expérience culinaire" avec un surcoût de 15 à 30%. À Nice, où la gastronomie méditerranéenne est un atout majeur, cette opportunité est particulièrement pertinente.</p>

      <h3>6. La Sécurité et la Confidentialité Comme Priorités Absolues</h3>
      
      <p>Les clients de luxe — souvent des personnalités publiques ou des investisseurs discrets — exigent une <strong>confidentialité absolue</strong>. Les propriétés avec systèmes de sécurité avancés, accès privés et gestion discrète des réservations commandent des tarifs premium.</p>
      
      <p>À Nice, où la clientèle internationale inclut des célébrités et des personnalités influentes, cette exigence est cruciale. Les propriétaires qui investissent dans la sécurité et la discrétion constatent une augmentation de 30 à 40% de leurs tarifs.</p>

      <h3>Conclusion : Adapter Votre Propriété aux Nouvelles Attentes</h3>
      
      <p>Le tourisme de luxe à Nice en 2025 n'est plus seulement une question de localisation ou de confort basique. C'est une <strong>combinaison d'authenticité, de durabilité, de technologie discrète et de services exceptionnels</strong>.</p>
      
      <p>Pour les propriétaires, cela signifie que la gestion professionnelle de leur bien devient essentielle. Une conciergerie experte peut non seulement gérer les réservations et la maintenance, mais aussi orchestrer ces expériences premium qui transforment un simple séjour en souvenir inoubliable.</p>
      
      <p>Chez Azur Concierge, nous comprenons ces tendances et les intégrons dans notre approche de gestion. Nous ne gérons pas simplement des propriétés : nous créons des destinations de luxe qui attirent une clientèle exigeante et fidèle.</p>
    `,
    author: "Azur Concierge",
    date: "13 Mars 2025",
    category: "Tendances",
    readTime: "8 min",
    image: "/blog-luxury-trends.jpg"
  }
];

export default function Blog() {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredPosts = blogPosts.filter(post =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.excerpt.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (selectedPost) {
    return (
      <div className="min-h-screen bg-black text-white overflow-hidden">
        {/* Navigation */}
        <nav className="fixed top-0 w-full bg-black/80 backdrop-blur-md border-b border-accent/20 z-50">
          <div className="container flex items-center justify-between h-16">
            <a href="/" className="text-2xl font-bold text-accent hover:text-yellow-400 transition-colors">Azur Concierge</a>
            <div className="hidden md:flex items-center gap-8">
              <a href="/#services" className="text-sm hover:text-accent transition-colors">Services</a>
              <a href="/about" className="text-sm hover:text-accent transition-colors">À Propos</a>
              <a href="/blog" className="text-sm text-accent font-semibold">Blog</a>
              <a href="/#faq" className="text-sm hover:text-accent transition-colors">FAQ</a>
            </div>
            <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="bg-accent text-black px-6 py-2 rounded-full font-semibold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105">
              Demande Privée
            </a>
          </div>
        </nav>

        {/* Article */}
        <article className="pt-32 pb-20">
          <div className="container max-w-3xl">
            {/* Back Button */}
            <button
              onClick={() => setSelectedPost(null)}
              className="flex items-center gap-2 text-accent hover:text-yellow-400 transition-colors mb-8"
            >
              <ArrowRight className="w-4 h-4 rotate-180" />
              Retour au blog
            </button>

            {/* Article Header */}
            <div className="mb-12">
              <div className="flex items-center gap-4 mb-6 text-sm text-gray-400">
                <span className="bg-accent/20 text-accent px-3 py-1 rounded-full">{selectedPost.category}</span>
                <span className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  {selectedPost.date}
                </span>
                <span>{selectedPost.readTime}</span>
              </div>

              <h1 className="text-5xl font-bold mb-6 leading-tight">{selectedPost.title}</h1>
              <p className="text-xl text-gray-400 mb-8">{selectedPost.excerpt}</p>

              <div className="flex items-center gap-4 pt-8 border-t border-accent/20">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
                  <User className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <p className="font-semibold">{selectedPost.author}</p>
                  <p className="text-sm text-gray-400">Expert en gestion Airbnb de luxe</p>
                </div>
              </div>
            </div>

            {/* Article Content */}
            <div className="prose prose-invert max-w-none">
              <div
                dangerouslySetInnerHTML={{ __html: selectedPost.content }}
                className="space-y-6 text-gray-300 leading-relaxed"
              />
            </div>

            {/* CTA */}
            <div className="mt-16 p-8 rounded-lg border border-accent/20 bg-accent/5 text-center">
              <h3 className="text-2xl font-bold mb-4">Prêt à optimiser votre propriété ?</h3>
              <p className="text-gray-400 mb-6">Découvrez comment Azur Concierge peut transformer votre bien en destination de luxe.</p>
              <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="inline-block bg-accent text-black px-8 py-4 rounded-lg font-bold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105">
                Planifier une consultation
              </a>
            </div>
          </div>
        </article>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-black/80 backdrop-blur-md border-b border-accent/20 z-50">
        <div className="container flex items-center justify-between h-16">
          <a href="/" className="text-2xl font-bold text-accent hover:text-yellow-400 transition-colors">Azur Concierge</a>
          <div className="hidden md:flex items-center gap-8">
            <a href="/#services" className="text-sm hover:text-accent transition-colors">Services</a>
            <a href="/about" className="text-sm hover:text-accent transition-colors">À Propos</a>
            <a href="/blog" className="text-sm text-accent font-semibold">Blog</a>
            <a href="/#faq" className="text-sm hover:text-accent transition-colors">FAQ</a>
          </div>
          <a href="https://calendly.com/jmb2nice/30min" target="_blank" rel="noopener noreferrer" className="bg-accent text-black px-6 py-2 rounded-full font-semibold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105">
            Demande Privée
          </a>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative h-96 flex items-center justify-center overflow-hidden pt-16">
        <div className="absolute inset-0 z-0 bg-gradient-to-br from-accent/10 to-black"></div>
        <div className="relative z-10 text-center max-w-3xl mx-auto px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Notre Blog</h1>
          <p className="text-xl text-gray-300">Tendances, conseils et insights sur la gestion Airbnb de luxe à Nice</p>
        </div>
      </section>

      {/* Search */}
      <section className="py-12 bg-black border-t border-accent/20">
        <div className="container max-w-2xl">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher un article..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-lg bg-black border border-accent/20 focus:border-accent focus:outline-none transition-colors text-white placeholder-gray-500"
            />
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-20 bg-black border-t border-accent/20">
        <div className="container">
          {filteredPosts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg">Aucun article trouvé. Essayez une autre recherche.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {filteredPosts.map((post) => (
                <div
                  key={post.id}
                  onClick={() => setSelectedPost(post)}
                  className="group rounded-lg border border-accent/20 hover:border-accent overflow-hidden hover:bg-accent/5 transition-all duration-300 cursor-pointer transform hover:-translate-y-2"
                >
                  <div className="h-48 bg-gradient-to-br from-accent/20 to-accent/5 flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-accent/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <span className="text-6xl group-hover:scale-125 transition-transform duration-300">📝</span>
                  </div>

                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-xs bg-accent/20 text-accent px-2 py-1 rounded">{post.category}</span>
                      <span className="text-xs text-gray-400">{post.readTime}</span>
                    </div>

                    <h3 className="text-xl font-bold mb-3 group-hover:text-accent transition-colors">{post.title}</h3>
                    <p className="text-gray-400 text-sm mb-4 line-clamp-2">{post.excerpt}</p>

                    <div className="flex items-center justify-between pt-4 border-t border-accent/20">
                      <span className="text-xs text-gray-500 flex items-center gap-2">
                        <Calendar className="w-3 h-3" />
                        {post.date}
                      </span>
                      <ArrowRight className="w-4 h-4 text-accent group-hover:translate-x-2 transition-transform" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-black border-t border-accent/20">
        <div className="container text-center max-w-2xl">
          <h2 className="text-4xl font-bold mb-6">Restez Informé</h2>
          <p className="text-gray-400 mb-8">Abonnez-vous à notre newsletter pour recevoir les dernières tendances et conseils sur la gestion Airbnb de luxe.</p>
          <div className="flex gap-4">
            <input
              type="email"
              placeholder="Votre email"
              className="flex-1 px-4 py-3 rounded-lg bg-black border border-accent/20 focus:border-accent focus:outline-none transition-colors text-white placeholder-gray-500"
            />
            <button className="bg-accent text-black px-8 py-3 rounded-lg font-bold hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105">
              S'abonner
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
