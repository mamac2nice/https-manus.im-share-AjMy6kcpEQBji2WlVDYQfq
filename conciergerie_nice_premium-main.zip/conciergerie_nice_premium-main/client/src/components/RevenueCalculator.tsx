import { useState } from 'react';
import { Calculator, TrendingUp } from 'lucide-react';

export default function RevenueCalculator() {
  const [apartmentType, setApartmentType] = useState('T2');
  const [location, setLocation] = useState('center');
  const [occupancyRate, setOccupancyRate] = useState(75);

  // Tarifs de base par type d'appartement (par nuit)
  const baseRates = {
    studio: { center: 60, promenade: 80, vieuxNice: 70 },
    T2: { center: 90, promenade: 120, vieuxNice: 100 },
    T3: { center: 130, promenade: 170, vieuxNice: 150 },
    T4: { center: 170, promenade: 220, vieuxNice: 190 },
  };

  // Multiplicateurs de localisation
  const locationMultipliers = {
    center: 1,
    promenade: 1.3,
    vieuxNice: 1.15,
  };

  // Calcul des revenus
  const calculateRevenue = () => {
    const baseRate = baseRates[apartmentType as keyof typeof baseRates][location as keyof typeof baseRates['T2']];
    const multiplier = locationMultipliers[location as keyof typeof locationMultipliers];
    const adjustedRate = baseRate * multiplier;
    
    // 30 jours par mois, occupancy rate en pourcentage
    const daysPerMonth = 30;
    const occupiedDays = (daysPerMonth * occupancyRate) / 100;
    const monthlyRevenue = adjustedRate * occupiedDays;
    
    // Commission Azur Concierge (25% en moyenne)
    const commission = monthlyRevenue * 0.25;
    const netRevenue = monthlyRevenue - commission;
    
    return {
      monthlyRevenue: Math.round(monthlyRevenue),
      commission: Math.round(commission),
      netRevenue: Math.round(netRevenue),
      yearlyRevenue: Math.round(monthlyRevenue * 12),
      yearlyNet: Math.round(netRevenue * 12),
    };
  };

  const revenue = calculateRevenue();

  const apartmentTypes = [
    { value: 'studio', label: 'Studio', icon: '🏠' },
    { value: 'T2', label: 'T2', icon: '🏠' },
    { value: 'T3', label: 'T3', icon: '🏠' },
    { value: 'T4', label: 'T4+', icon: '🏠' },
  ];

  const locations = [
    { value: 'center', label: 'Nice Centre', icon: '🏙️' },
    { value: 'promenade', label: 'Promenade des Anglais', icon: '🌊' },
    { value: 'vieuxNice', label: 'Vieux Nice', icon: '🏛️' },
  ];

  return (
    <div className="w-full bg-gradient-to-br from-black via-black to-accent/5 rounded-2xl border border-accent/30 p-8 md:p-12">
      <div className="flex items-center gap-3 mb-8">
        <Calculator className="w-8 h-8 text-accent" />
        <h3 className="text-3xl font-bold">Calculateur de Revenus</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Formulaire */}
        <div className="space-y-8">
          {/* Type d'appartement */}
          <div>
            <label className="block text-sm font-semibold mb-4 text-accent">Type d'appartement</label>
            <div className="grid grid-cols-4 gap-3">
              {apartmentTypes.map((type) => (
                <button
                  key={type.value}
                  onClick={() => setApartmentType(type.value)}
                  className={`p-3 rounded-lg border-2 transition-all duration-300 text-center ${
                    apartmentType === type.value
                      ? 'border-accent bg-accent/20 text-accent'
                      : 'border-accent/30 bg-black/50 text-gray-400 hover:border-accent/50'
                  }`}
                >
                  <div className="text-2xl mb-1">{type.icon}</div>
                  <div className="text-xs font-bold">{type.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Localisation */}
          <div>
            <label className="block text-sm font-semibold mb-4 text-accent">Localisation</label>
            <div className="space-y-2">
              {locations.map((loc) => (
                <button
                  key={loc.value}
                  onClick={() => setLocation(loc.value)}
                  className={`w-full p-3 rounded-lg border-2 transition-all duration-300 text-left flex items-center gap-3 ${
                    location === loc.value
                      ? 'border-accent bg-accent/20'
                      : 'border-accent/30 bg-black/50 hover:border-accent/50'
                  }`}
                >
                  <span className="text-2xl">{loc.icon}</span>
                  <span className="font-semibold">{loc.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Taux d'occupation */}
          <div>
            <label className="block text-sm font-semibold mb-4 text-accent">
              Taux d'occupation : <span className="text-white">{occupancyRate}%</span>
            </label>
            <input
              type="range"
              min="30"
              max="100"
              value={occupancyRate}
              onChange={(e) => setOccupancyRate(Number(e.target.value))}
              className="w-full h-2 bg-accent/20 rounded-lg appearance-none cursor-pointer accent-accent"
            />
            <div className="flex justify-between text-xs text-gray-400 mt-2">
              <span>30%</span>
              <span>50%</span>
              <span>75%</span>
              <span>100%</span>
            </div>
          </div>
        </div>

        {/* Résultats */}
        <div className="bg-gradient-to-br from-accent/10 to-accent/5 rounded-xl border border-accent/30 p-8 flex flex-col justify-center">
          <div className="mb-8">
            <p className="text-gray-400 text-sm mb-2">Revenus bruts estimés (mensuel)</p>
            <div className="text-5xl font-bold text-accent mb-2">{revenue.monthlyRevenue.toLocaleString()}€</div>
            <p className="text-gray-400 text-xs">Avant commission Azur Concierge</p>
          </div>

          <div className="border-t border-accent/30 pt-6 mb-6">
            <p className="text-gray-400 text-sm mb-2">Commission Azur Concierge (25%)</p>
            <p className="text-2xl font-bold text-accent/80">-{revenue.commission.toLocaleString()}€</p>
          </div>

          <div className="bg-accent/20 rounded-lg p-6 mb-8">
            <p className="text-gray-300 text-sm mb-2">Revenus nets (mensuel)</p>
            <div className="text-4xl font-bold text-accent">{revenue.netRevenue.toLocaleString()}€</div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-6 border-t border-accent/30">
            <div>
              <p className="text-gray-400 text-xs mb-1">Annuel brut</p>
              <p className="text-2xl font-bold text-accent">{revenue.yearlyRevenue.toLocaleString()}€</p>
            </div>
            <div>
              <p className="text-gray-400 text-xs mb-1">Annuel net</p>
              <p className="text-2xl font-bold text-accent">{revenue.yearlyNet.toLocaleString()}€</p>
            </div>
          </div>

          <div className="mt-8 p-4 bg-black/50 rounded-lg border border-accent/20">
            <p className="text-xs text-gray-400 mb-2">💡 Astuce</p>
            <p className="text-sm text-gray-300">Avec notre expertise, nous augmentons généralement le taux d'occupation de <span className="text-accent font-bold">+30%</span> et les tarifs de <span className="text-accent font-bold">+20%</span>.</p>
          </div>
        </div>
      </div>

      <div className="mt-8 p-6 bg-accent/10 rounded-lg border border-accent/30 flex items-start gap-4">
        <TrendingUp className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
        <div>
          <p className="font-semibold mb-2">Estimations basées sur nos données réelles</p>
          <p className="text-sm text-gray-400">Ces chiffres sont calculés à partir de nos 20+ propriétés gérées et +1200 voyageurs accueillis. Les résultats peuvent varier selon la saison et les conditions du marché local.</p>
        </div>
      </div>
    </div>
  );
}
